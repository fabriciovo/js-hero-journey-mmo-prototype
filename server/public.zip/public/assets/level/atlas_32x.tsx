<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="atlas_32x" tilewidth="32" tileheight="32" tilecount="1536" columns="96">
 <image source="../images/atlas_32x.png" width="3072" height="512"/>
</tileset>
